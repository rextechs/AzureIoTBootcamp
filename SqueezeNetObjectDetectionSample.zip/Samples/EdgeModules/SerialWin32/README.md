# SerialWin32 Azure IoT Edge module

These are the available versions of this Azure IoT Edge module sample:

*	[C#](./CS/README.md)

This project has adopted the Microsoft Open Source Code of Conduct. For more information see the Code of Conduct FAQ or contact <opencode@microsoft.com> with any additional questions or comments.