﻿//
// Copyright (c) Microsoft. All rights reserved.
//

namespace EdgeModuleSamples.Messages
{
    public class FruitMessage
    {
        public string FruitSeen { get; set; }
    }
}
