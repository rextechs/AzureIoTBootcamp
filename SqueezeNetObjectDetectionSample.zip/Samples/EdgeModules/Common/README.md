# Common components across many modules

This directory contains a classes library for classes shared by multiple samples.

* [C#](./cs/README.md)

This project has adopted the Microsoft Open Source Code of Conduct. For more information see the Code of Conduct FAQ or contact <opencode@microsoft.com> with any additional questions or comments